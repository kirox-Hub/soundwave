# 🎵 SoundWave

## Déploiement sur Render (gratuit)

### Étape 1 — Crée un compte GitHub
Va sur https://github.com et crée un compte gratuit.

### Étape 2 — Crée un nouveau repo
1. Clique sur "New repository"
2. Nom : `soundwave`
3. Public
4. Clique "Create repository"

### Étape 3 — Upload les fichiers
1. Clique "uploading an existing file"
2. Glisse TOUS les fichiers du dossier (app.py, requirements.txt, Procfile, render.yaml, templates/, static/)
3. Clique "Commit changes"

### Étape 4 — Déploie sur Render
1. Va sur https://render.com → créer un compte gratuit
2. "New" → "Web Service"
3. Connecte ton GitHub → sélectionne le repo `soundwave`
4. Render détecte tout automatiquement grâce au render.yaml
5. Clique "Deploy"

### Étape 5 — Ton site est en ligne !
Render te donne une URL du type : https://soundwave-xxxx.onrender.com
